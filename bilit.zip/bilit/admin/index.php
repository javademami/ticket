<?php

session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit();
}
?>
<?php
include_once 'header.php'; 
include_once 'dbconfig.php';
?>


  <div class="space"></div>           
<div class="clearfix"></div>

<div class="container">
<a href="add-data.php" class="btn btn-large btn-info"><i class="glyphicon glyphicon-plus"></i> &nbsp; Add Ticket</a>
</div>

<div class="clearfix"></div><br />

    
<div class="container">
     <table class='table table-bordered table-responsive'>
     <tr>
     <th>Event ID</th>
     <th>Event Name</th>
     <th>Event Price</th>
     <th>Event Description</th>
     <th>Event Date</th>
     <th colspan="2" align="center">Actions</th>
     </tr>
     <?php
      $query = "SELECT * FROM tbl_events";       
      $records_per_page=10;
      $newquery = $crud->paging($query,$records_per_page);
      $crud->dataview($newquery);
      ?>
    <tr>
        <td colspan="7" align="center">
    <div class="pagination-wrap">
            <?php $crud->paginglink($query,$records_per_page); ?>
         </div>
        </td>
    </tr>
 
</table>
   
       
</div>

<?php include_once 'footer.php'; ?>