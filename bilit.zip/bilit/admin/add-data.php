<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit();
}
?>
<?php
include_once 'dbconfig.php';
include_once 'header.php';

if(isset($_POST['btn-save'])) {
    $evname = $_POST['event_name'];
    $evprice = $_POST['event_price'];
    $evdesc = $_POST['event_desc'];
    $evpic = $_POST['event_pic'];
    $folder ="uploads/"; 

$image = $_FILES['image']['name']; 

$path = $folder . $image ; 

$target_file=$folder.basename($_FILES["image"]["name"]);

 
 $imageFileType=pathinfo($target_file,PATHINFO_EXTENSION);

 
$allowed=array('jpeg','png' ,'jpg'); $filename=$_FILES['image']['name']; 

$ext=pathinfo($filename, PATHINFO_EXTENSION); if(!in_array($ext,$allowed) ) 

{ 

 echo "Sorry, only JPG, JPEG, PNG & GIF  files are allowed.";

}

else{ 

move_uploaded_file( $_FILES['image'] ['tmp_name'], $path); 

$sth=$dbc->prepare("insert into tbl_events(pix)values(:image) "); 

$sth->bindParam(':image',$image); 

$sth->execute(); 

} 


    
    if($crud->create($evname, $evprice, $evdesc, $evpic)) {
        header("location: add-data.php?inserted");
    } else {
        header("location: add-data.php?failure");
    }
}
?>

<div class="space"></div>
<div class="clearfix"></div>
<?php
if(isset($_GET['inserted'])) {  
?>
<div class="container">
    <div class="alert alert-success">
        Successfully inserted<a href="index.php">&nbsp;HOME</a>!
    </div>
</div>
<?php 
} else if(isset($_GET['failure'])) {
?>
<div class="container">
    <div class="alert alert-warning">
        <strong>Opp!</strong>Error while inserting data!
    </div>
</div>
<?php
}
?>

<div class="clearfix"></div><br/>
<div class="container">
    <form method="post">
        <table class="table table-bordered">
            <tr>
                <td>Event Name</td>
                <td><input type="text" name="event_name" class="form-control" required /></td>
            </tr>
            <tr>
                <td>Ticket Price</td>
                <td><input type="text" name="event_price" class="form-control" required /></td>
            </tr>
            <tr>
                <td>Event Description</td>
                <td><textarea  name="event_desc" class="form-control" required /></textarea></td>
            </tr>
            <tr>
                <td>Event Date</td>
                <td><input type="text" name="event_pic" class="form-control" required /></td>
            </tr>
           
            <tr>
                <td colspan="2"><button type="submit" class="btn btn-primary" name="btn-save">
                <span class="glyphicon glyphicon-plus"></span>Create New Ticket
                </button>
                    <a href="index.php" class="btn btn-large btn-danger"><i class="glyphicon glyphicon-backward"></i>&nbsp;Back to index</a>
                </td>
            </tr>
        </table>
    </form>
</div>
<?php include_once 'footer.php'; ?>
