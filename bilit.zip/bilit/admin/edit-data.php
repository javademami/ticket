<?php
// We need to use sessions, so you should always start sessions using the below code.
session_start();
// If the user is not logged in redirect to the login page...
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit();
}
?>
<?php
include_once 'dbconfig.php';
include_once 'header.php';
if(isset($_POST['btn-update'])) {
    $id = $_GET['edit_id'];
    $evname = $_POST['event_name'];
    $evprice = $_POST['event_price'];
    $evdesc = $_POST['event_desc'];
    $evpic = $_POST['event_pic'];
    
    if($crud->update($id, $evname, $evprice, $evdesc, $evpic)) {
        $sms = "<div class='alert alert-success'>
                <strong>Yesh!</strong>Successfully updated
                <a href='index.php'>HOME</a>!</div>";
    } else {
        $sms = "<div class='alert alert-warning'>
                <strong>Oop!</strong>Error while updating record!
                </div>";
    }
}
if(isset($_GET['edit_id'])) {
    $id = $_GET['edit_id'];
    extract($crud->getID($id));
}
?>
 <div class="space"></div>  
<div class="clearfix"></div>
<div class="container">
<?php
    if(isset($sms)) {
        echo $sms;
    }
?>
</div>
<div class="clearfix"></div><br/>
<div class="container">
    <form method="post">
        <table class="table table-bordered">
            <tr>
                <td>Event Name</td>
                <td>
                    <input type="text" name="event_name" class="form-control" value="<?php echo $evname; ?>" required />
                </td>
            </tr>
            <tr>
                <td>Ticket Price</td>
                <td>
                    <input type="text" name="event_price" class="form-control" value="<?php echo $evprice; ?>" required />
                </td>
            </tr>
            <tr>
                <td>Event Description</td>
                <td>
                    <input type="text" name="event_desc" class="form-control" value="<?php echo $evdesc; ?>" required />
                </td>
            </tr>
            <tr>
                <td>Event </td>
                <td>
                    <input type="text" name="event_pic" class="form-control" value="<?php echo $evpic; ?>" required />
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <button type="submit" class="btn btn-primary" name="btn-update">
                        <span class="glyphicon glyphicon-edit"></span>Update this record
                    </button>
                    <a href="index.php" class="btn btn-large btn-danger"><i class="glyphicon glyphicon-backward"></i>&nbsp; CANCEL</a>
                </td>
            </tr>
        </table>
    </form>
</div>

<?php include_once 'footer.php'; ?>