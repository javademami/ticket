<div class="container">
 <div class="alert alert-info">
 <strong>Developted BY </strong> <a href="http://www.javadstudio.se">Javad Emami</a>
 </div>
</div>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>
</html>