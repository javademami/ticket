<?php
require_once('config.php'); 
include_once 'header.php'; 
?>
  <body>
    <div class="container">
    <div class="row">
    <div class="col-md-5">
    <div id="cart" class="mt-20">
    </div>
    </div>
    <?php
    $sql= "SELECT * FROM tbl_events ORDER BY eventID DESC";
    $stmt = $conn->prepare($sql); $stmt->execute(); $result = $stmt->fetchAll(); ?>
    <div class="col-md-7 top">
        <div class="row">
            
    <?php
    foreach($result as $row){
    echo "
    <div class='col-md-6'>
    <div class='card' style=''>
    <img class='card-img-top' src='admin/uploads/banner.jpg'>
    <div class='card-body'>
    <h5 class='card-title id=''><i class='fas fa-microphone-alt'></i> {$row['eventName']}
    <p class='card-text'>{$row['eventDescription']}</p>
    <p id='products'><i class='fas fa-calendar-alt'></i> {$row['eventPic']}</p>                   
                            
    <p class='card-text'><i class='fas fa-money-bill-wave'></i> {$row['eventPrice']} $</p>
    <button
     class='btn btn-primary sc-add-to-cart'
     data-name='{$row['eventName']}'
     data-price='{$row['eventPrice']}'
    type='submit'>Add
   </button>
    </div>
     </div>
     </div>
     
                      
                    ";
                }
                
                    ?>
                     </div>
                     </div>
                    </div>
            </div>
            
       
    <script
      src="https://code.jquery.com/jquery-1.12.4.min.js"
      integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ"
      crossorigin="anonymous"
    ></script>
    <script src="lib/js/mycart.js"></script>
    <script>
      $(document).ready(function() {
        $("#cart").simpleCart();
      });
    </script>
  </body>
  <script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(["_setAccount", "UA-36251023-1"]);
    _gaq.push(["_setDomainName", "jqueryscript.net"]);
    _gaq.push(["_trackPageview"]);

    (function() {
      var ga = document.createElement("script");
      ga.type = "text/javascript";
      ga.async = true;
      ga.src =
        ("https:" == document.location.protocol
          ? "https://ssl"
          : "http://www") + ".google-analytics.com/ga.js";
      var s = document.getElementsByTagName("script")[0];
      s.parentNode.insertBefore(ga, s);
    })();
  </script>
</html>
